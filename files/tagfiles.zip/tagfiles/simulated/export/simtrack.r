library(trackit)
track <- read.csv('Tag2light.csv')
sst <- read.csv('Tag2sst.csv')
pt <- prepit(track, fix.first=c(202.203,32.87,2008,6,16,0,0,0),
		    fix.last=c(201.34,33.81,2008,7,4,0,0,0), scan=F)
fit <- trackit(pt, rad.ph=-1, D.ph=2, bsst.ph=-1)

track <- read.csv('Tag3light.csv')
sst <- read.csv('Tag3sst.csv')
pt <- prepit(track, fix.first=c(202.52,32.68,2002,6,29,0,0,0),
		    fix.last=c(201.154,34.34,2002,10,25,0,0,0), scan=F)
fit <- trackit(pt, rad.ph=-1, D.ph=2, bsst.ph=-1)


