#------------------------------------------------------------------
# Simulated processing of tracks in R using "Trackit"
# http://www.int-res.com/abstracts/meps/v419/p71-84
#
# 1. Recommend R version 2.8 to 2.10.1
# http://cran.r-project.org/bin/windows/base/old/2.8.1
#
# 2. R libraries for Trackit can be downloaded here
# http://tagbase.googlecode.com/svn/trunk/files/library.zip
# Instructions: unzip the file and move the folders into
#               your installed R library directory.
# To find out where your R library folder is located, type in R:
# > library()
# And look for something like this:
# "Packages in library 'C:/R/R-2.8.1/library':"
#------------------------------------------------------------------

# Note: delete the hash sign (#) to uncomment a line

# Preparation; define working directory
setwd("C:/Tagbase/tagfiles/simulated/export")
# Save data to
savefile <- "C:/Tagbase/tagfiles/simulated/outputs/simtracks.Rdata"

# Main code:
library(trackit)
track <- read.csv('Tag2light.csv')
# sst <- read.csv('Tag2sst.csv') # Using only light
pt <- prepit(track, fix.first=c(202.203,32.87,2008,6,16,0,0,0),
		    fix.last=c(201.34,33.81,2008,7,4,0,0,0), scan=F)
tag2 <- trackit(pt, D.ph=2, D.i=400)

track <- read.csv('Tag3light.csv')
# sst <- read.csv('Tag3sst.csv') # Using only light
pt <- prepit(track, fix.first=c(202.52,32.68,2002,6,29,0,0,0),
		    fix.last=c(201.154,34.34,2002,10,25,0,0,0), scan=F)
tag3 <- trackit(pt, ss3.ph=4)

save(tag2,tag3,file=savefile)
