### Name: trackit
### Title: trackit: Light based tracking
### Aliases: trackit
### Keywords: models

### ** Examples

  # No examples provided here, but try the ones in ?drifter and ?mooring



