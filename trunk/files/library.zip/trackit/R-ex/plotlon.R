### Name: plotlon
### Title: Longitude plot
### Aliases: plotlon
### Keywords: models

### ** Examples

  # No examples provided here, but try the ones in ?drifter and ?mooring



