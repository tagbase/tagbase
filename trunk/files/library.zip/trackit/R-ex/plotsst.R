### Name: plotsst
### Title: SST plot
### Aliases: plotsst
### Keywords: models

### ** Examples

  # No examples provided here, but try the ones in ?drifter and ?mooring



