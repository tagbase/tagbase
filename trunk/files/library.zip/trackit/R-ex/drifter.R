### Name: drifter
### Title: drifter
### Aliases: drifter
### Keywords: datasets

### ** Examples

  data(drifter)
  prep.track<-prepit(drifter, fix.first=c(360-161.45,22.85,2002,9,10,0,0,0), 
                              fix.last=c(360-159.87,21.95,2003,5,21,0,0,0), scan=FALSE)
  # try to run (not in the example, because it takes a while)
  #   fit<-trackit(prep.track)
  #   plot(fit)



