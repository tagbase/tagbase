### Name: prepit
### Title: Prepare a track for light based geolocation
### Aliases: prepit
### Keywords: models

### ** Examples

  # No examples provided here, but try the ones in ?drifter and ?mooring



