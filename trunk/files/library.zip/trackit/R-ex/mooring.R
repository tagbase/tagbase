### Name: mooring
### Title: mooring
### Aliases: mooring
### Keywords: datasets

### ** Examples

  data(mooring)
  prep.track<-prepit(mooring, fix.first=c(166.47,-22.48,2003,9,8,2,32,0), 
                              fix.last=c(166.47,-22.48,2004,4,19,16,49,0))
  # try to run (not in the example, because it takes a while)
  #   fit<-trackit(prep.track)
  #   plot(fit)



