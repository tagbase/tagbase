### Name: plotbasemap
### Title: Plot land area on a map with colored polygons
### Aliases: plotbasemap
### Keywords: models

### ** Examples

  plotbasemap(8,13,53,58)



