### Name: plot.trackit
### Title: Plot a fitted track
### Aliases: plot.trackit
### Keywords: models

### ** Examples

  # No examples provided here, but try the ones in ?drifter and ?mooring



