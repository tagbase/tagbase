### Name: get.avhrr.sst
### Title: Get SST-field from avhrr source
### Aliases: get.avhrr.sst
### Keywords: models

### ** Examples

  # No example supplied here



