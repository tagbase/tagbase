### Name: gmt3
### Title: gmt3
### Aliases: gmt3
### Keywords: datasets

### ** Examples

  data(gmt3)



