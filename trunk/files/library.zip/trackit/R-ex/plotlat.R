### Name: plotlat
### Title: Latitude plot
### Aliases: plotlat
### Keywords: models

### ** Examples

  # No examples provided here, but try the ones in ?drifter and ?mooring



