### Name: deltat
### Title: deltat
### Aliases: deltat
### Keywords: datasets

### ** Examples

  data(deltat)
  plot(deltat[,3]+deltat[,2]/12, deltat[,4], xlab="year", ylab=expression(Delta*T))



