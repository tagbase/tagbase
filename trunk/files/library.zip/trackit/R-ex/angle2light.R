### Name: angle2light
### Title: angle2light
### Aliases: angle2light
### Keywords: datasets

### ** Examples

  data(angle2light)
  plot(angle2light, type='l', lwd=3, col='red')



