### Name: light.simulator
### Title: Simulate artificial datasets
### Aliases: light.simulator
### Keywords: models

### ** Examples

  # No examples provided here, but try the ones in ?drifter and ?mooring



