### Name: write.html
### Title: Write html page with a map of the track(s)
### Aliases: write.html
### Keywords: programming

### ** Examples

  data(big.241)
  fit<-kftrack(big.241, fix.last=FALSE)
  write.html(fit)
  #browseURL(normalizePath('track.html'))



