### Name: plot.kftrack
### Title: Plot a kftrack object
### Aliases: plot.kftrack
### Keywords: programming

### ** Examples

data(big.241)
fit<-kftrack(big.241, fix.last=FALSE)
plot(fit)



