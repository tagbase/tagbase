### Name: big.241
### Title: Data for bigeye tuna tag number 241
### Aliases: big.241
### Keywords: datasets

### ** Examples

data(big.241)
big.241[1:10,]
#fit<-kftrack(big.241, fix.last=FALSE)
#plot(fit)



