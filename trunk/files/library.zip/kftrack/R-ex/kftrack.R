### Name: kftrack
### Title: Kalman filter tracking (of tagged individuals)
### Aliases: kftrack
### Keywords: programming

### ** Examples

data(big.241)
fit<-kftrack(big.241, fix.last=FALSE)
plot(fit)



