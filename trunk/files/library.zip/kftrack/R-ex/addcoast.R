### Name: addcoast
### Title: Adds coastline to plotted track
### Aliases: addcoast
### Keywords: programming

### ** Examples

  data(big.241)
  fit<-kftrack(big.241, fix.last=FALSE)
  plot(fit)
  addcoast()



