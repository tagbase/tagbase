### Name: addmap
### Title: Adds map to plotted track
### Aliases: addmap
### Keywords: programming

### ** Examples

  data(big.241)
  fit<-kftrack(big.241, fix.last=FALSE)
  plot(fit)
  addmap(fit)



