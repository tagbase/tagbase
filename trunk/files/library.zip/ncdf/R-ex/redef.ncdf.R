### Name: redef.ncdf
### Title: Puts a netCDF file back into define mode
### Aliases: redef.ncdf
### Keywords: utilities

### ** Examples

# This function is for advanced useage only, and will never
# be needed by the typical users R code.



