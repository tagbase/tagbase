### Name: close.ncdf
### Title: Close a netCDF File
### Aliases: close.ncdf
### Keywords: utilities

### ** Examples

## Not run: nc <- open.ncdf("salinity.nc")
## Not run: data <- get.var.ncdf( nc )     # Read the "only" var in the file
## Not run: close.ncdf(nc)



