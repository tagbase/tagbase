### Name: enddef.ncdf
### Title: Takes a netCDF file out of define mode
### Aliases: enddef.ncdf
### Keywords: utilities

### ** Examples

# This function is for advanced useage only, and will never
# be needed by the typical users R code.



