### Name: print.ncdf
### Title: Print Information About a netCDF File
### Aliases: print.ncdf
### Keywords: utilities

### ** Examples

# Open a netCDF file, print information about it
nc <- open.ncdf( "salinity.nc" )
print(nc)



