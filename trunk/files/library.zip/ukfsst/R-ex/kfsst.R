### Name: kfsst
### Title: Kalman Filter based optimization of the tracking model including
###   Sea Surface Temperature
### Aliases: kfsst
### Keywords: models

### ** Examples

  # No example supplied here, but check out the example 
  # in the blue.shark dataset documentation



