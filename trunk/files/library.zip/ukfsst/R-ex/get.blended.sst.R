### Name: get.blended.sst
### Title: Get SST-field from blended source
### Aliases: get.blended.sst
### Keywords: models

### ** Examples

  # No example supplied here, but check out the example 
  # in the blue.shark dataset documentation



