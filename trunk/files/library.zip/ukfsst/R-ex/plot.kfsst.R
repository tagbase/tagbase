### Name: plot.kfsst
### Title: Plot a fit from kfsst.
### Aliases: plot.kfsst
### Keywords: models

### ** Examples

  # No example supplied here, but check out the example 
  # in the blue.shark dataset documentation



