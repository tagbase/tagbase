### Name: plotmap
### Title: Plot land area on a map with colored polygons
### Aliases: plotmap
### Keywords: models

### ** Examples

  #This function requires GMT to be installed. If you have it try typing:
  #  plotmap(8,13,53,58,res=1,zoom=TRUE)



