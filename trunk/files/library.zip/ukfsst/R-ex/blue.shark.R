### Name: blue.shark
### Title: A track of a blue shark released near Hawai'i
### Aliases: blue.shark
### Keywords: datasets

### ** Examples

  data(blue.shark)
  sst.path<-get.sst.from.server(blue.shark)
  fit<-kfsst(blue.shark, bx.active=FALSE, bsst.active=FALSE)
  plot(fit, ci=TRUE, pred=FALSE)  



