### Name: as.date
### Title: Coerce Data to Dates
### Aliases: as.date
### Keywords: chron

### ** Examples

as.date(c("1jan1960", "2jan1960", "31mar1960", "30jul1960"))



