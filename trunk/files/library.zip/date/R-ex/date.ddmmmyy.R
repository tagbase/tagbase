### Name: date.ddmmmyy
### Title: Format a Julian date
### Aliases: date.ddmmmyy
### Keywords: chron

### ** Examples

date.ddmmmyy(1:10)



