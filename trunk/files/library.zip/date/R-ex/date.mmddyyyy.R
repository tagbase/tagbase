### Name: date.mmddyyyy
### Title: Format a Julian date
### Aliases: date.mmddyyyy
### Keywords: chron

### ** Examples

date.mmddyyyy(as.date(1:10))



