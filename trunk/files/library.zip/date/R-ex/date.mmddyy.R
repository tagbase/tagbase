### Name: date.mmddyy
### Title: Format a Julian date
### Aliases: date.mmddyy
### Keywords: chron

### ** Examples

date.mmddyy(as.date(10))



