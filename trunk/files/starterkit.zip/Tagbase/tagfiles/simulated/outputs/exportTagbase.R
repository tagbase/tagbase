#------------------------------------------------------------------
# Export saved tracks from R that are processed with "Trackit"
# http://www.int-res.com/abstracts/meps/v419/p71-84
#------------------------------------------------------------------

# Note: delete the hash sign (#) to uncomment a line

# Preparation; define working directory:
setwd("C:/Tagbase/tagfiles/simulated/outputs")

# Main code:

source("fit2csv.R")
load("simtracks.Rdata")
fit2csv(tag2)
fit2csv(tag3)
